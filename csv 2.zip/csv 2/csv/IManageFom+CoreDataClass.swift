//
//  IManageFom+CoreDataClass.swift
//  csv
//
//  Created by Muthupalaniappan S on 29/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData

@objc(IManageFom)
public class IManageFom: NSManagedObject {

}
