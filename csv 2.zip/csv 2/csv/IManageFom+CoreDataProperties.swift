//
//  IManageFom+CoreDataProperties.swift
//  csv
//
//  Created by Muthupalaniappan S on 29/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData


extension IManageFom {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<IManageFom> {
        return NSFetchRequest<IManageFom>(entityName: "IManageFom");
    }

    @NSManaged public var account: String?
    @NSManaged public var deploymenttype: String?
    @NSManaged public var email: String?
    @NSManaged public var firstname: String?
    @NSManaged public var lastname: String?
    @NSManaged public var notes: String?
    @NSManaged public var organisationtype: String?
    @NSManaged public var phonenumber: Int16
    @NSManaged public var products: String?
    @NSManaged public var timeframe: String?
    @NSManaged public var title: String?
    @NSManaged public var urgency: Int16
    @NSManaged public var company: String?

}
