//
//  ViewController.swift
//  csv
//
//  Created by Boobesh Balasubramanian on 14/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource,UIGestureRecognizerDelegate {
    
    /*Collection of outlets and actions for the matched view controller  */
    
    @IBOutlet var firstNameTextfield: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var emailAddressTextField: UITextField!
    @IBOutlet weak var company: UITextField!
    @IBOutlet weak var listOfProductsLabel: UILabel!
    @IBOutlet weak var deploymentTypeLabel: UILabel!
    @IBOutlet weak var organisationTypeLabel: UILabel!
    @IBOutlet weak var timeFrameLabel: UILabel!
    @IBOutlet weak var notesTextField: UITextView!
    @IBOutlet weak var accountTypeLabel: UILabel!
    @IBOutlet weak var urgencyTypeLabel: UILabel!
    
    
    @IBAction func submitFormButton(_ sender: Any) {
//        let firsName = firstNameTextfield.text
//        let lastName = lastNameTextField.text
//        let title = titleTextField.text
//        let phoneNumber = phoneNumberTextField.text
//        let email = emailAddressTextField.text
//        let comoany = company.text
//        let notes = notesTextField.text
//        let selectedProducts = labelsValuesDictionary["IManageProducts"]
//        let selectedDeployment_Types = labelsValuesDictionary["DeploymentTypes"]
//        let selectedOrganisation_Types = labelsValuesDictionary["TypeOfOrganisations"]
//        let selectedtimeFrame = labelsValuesDictionary["TimeFrame"]
//        let selectedAccountType = labelsValuesDictionary["SDFCAccountType"]
//        let selectedUrgencyType = labelsValuesDictionary["urgency"]
        
        
        formValueDictionary["firsName"] = firstNameTextfield.text
        formValueDictionary["lastName"] = lastNameTextField.text
        formValueDictionary["title"] = titleTextField.text
        formValueDictionary["phoneNumber"] = phoneNumberTextField.text
        formValueDictionary["email"] = emailAddressTextField.text
        formValueDictionary["comoany"] = company.text
        formValueDictionary["notes"] = notesTextField.text
        formValueDictionary["selectedProducts"] = labelsValuesDictionary["IManageProducts"]
        formValueDictionary["selectedDeployment_Types"] = labelsValuesDictionary["DeploymentTypes"]
        formValueDictionary["selectedOrganisation_Types"] = labelsValuesDictionary["TypeOfOrganisations"]
        formValueDictionary["selectedtimeFrame"] = labelsValuesDictionary["TimeFrame"]
        formValueDictionary["selectedAccountType"] = labelsValuesDictionary["SDFCAccountType"]
        formValueDictionary["selectedUrgencyType"] = labelsValuesDictionary["urgency"]
        print("object type \(type(of: formValueDictionary))")   
//        imanageForm.firstname = firstNameTextfield.text
//        imanageForm.lastname = lastNameTextField.text
//        imanageForm.title = titleTextField.text
//        imanageForm.phonenumber = Int16(phoneNumberTextField.text!)!
//        imanageForm.email = emailAddressTextField.text
//        imanageForm.company =  company.text
//        imanageForm.notes = notesTextField.text
//        imanageForm.products = labelsValuesDictionary["IManageProducts"]
//        imanageForm.organisationtype = labelsValuesDictionary["TypeOfOrganisations"]
//        imanageForm.timeframe = labelsValuesDictionary["TimeFrame"]
//        imanageForm.deploymenttype = labelsValuesDictionary["DeploymentTypes"]
//        imanageForm.account = labelsValuesDictionary["SDFCAccountType"]
//        imanageForm.urgency = Int16(labelsValuesDictionary["urgency"]!)!
        
        
        
        
//        print("the form values are \(firsName) \(lastName)\(title)\(phoneNumber)\(email)\(comoany)\(notes)\(selectedProducts)\(selectedDeployment_Types)\(selectedOrganisation_Types)\(selectedtimeFrame)\(selectedAccountType)\(selectedUrgencyType)")
       
        
        ImanageFormObject.InsertFormDetails(formFields:formValueDictionary)
             ImanageFormObject.fetchFormDetails()
    
    }
    
    
    
    /* Datasource array's for the picker view  */
    
    let IManageProducts = ["iManage work", "iManage Share"," iManage Insight", "iManage govern" , "MFP integration", "Process Automation"]
    let DeploymentTypes = ["Onpremis", "cloud"]
    let TypeOfOrganisations = ["Law firm", "Corporate legal departmnet"]
    let TimeFrame = ["In the next 12 months", "12 to 24 months", "more than 24 months"]
    let SDFCAccountType = ["Client", "Prospect"]
    let urgency = ["1","2","3"]
    let labelNamesArray = ["IManageProducts","DeploymentTypes","TypeOfOrganisations","TimeFrame","SDFCAccountType","urgency"]
    var labelsArray = Array<Array<String>>()
    var labelsValuesDictionary = [String:String]()
    var imanageForm:IManageFom = IManageFom()
    let ImanageFormObject  = DatabaseHelper()
    var formValueDictionary=[String:String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /* adding gestures to the corresponding views */
        
        labelsArray.append(IManageProducts)
        labelsArray.append(DeploymentTypes)
        labelsArray.append(TypeOfOrganisations)
        labelsArray.append(TimeFrame)
        labelsArray.append(SDFCAccountType)
        labelsArray.append(urgency)
        
        listOfProductsLabel.addGestureRecognizer(gestureProvider())
        deploymentTypeLabel.addGestureRecognizer(gestureProvider())
        organisationTypeLabel.addGestureRecognizer(gestureProvider())
        timeFrameLabel.addGestureRecognizer(gestureProvider())
        accountTypeLabel.addGestureRecognizer(gestureProvider())
        urgencyTypeLabel.addGestureRecognizer(gestureProvider())
        
        
        /* initialize core data stack */
        
        //ImanageFormObject =  DatabaseHelper()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func labelTapGestureHandler(sender:UITapGestureRecognizer){
        generatePicker(pickerTags: sender.view!.tag)
    }
    
    
    func gestureProvider()->UITapGestureRecognizer{
        print("gesture provided to all labels ")
        let tapGesture = UITapGestureRecognizer(target: self, action:#selector(labelTapGestureHandler(sender:)))
        tapGesture.delegate = self
        tapGesture.numberOfTouchesRequired = 1
        tapGesture.numberOfTapsRequired = 1
        return tapGesture
        
    }
    
    
    func generatePicker(pickerTags:Int) {
        let vc = UIViewController()
        vc.preferredContentSize = CGSize(width: 250,height: 300)
        let pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: 250, height: 300))
        pickerView.delegate = self
        pickerView.dataSource = self
        pickerView.tag = pickerTags
        vc.view.addSubview(pickerView)
        let pickerAlert = UIAlertController(title: "choose \(labelNamesArray[pickerTags])", message: "", preferredStyle: UIAlertControllerStyle.alert)
        pickerAlert.setValue(vc, forKey: "contentViewController")
        pickerAlert.addAction(UIAlertAction(title: "Done", style: .default, handler: nil))
        pickerAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(pickerAlert, animated: true)
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return givePickerCount(forPickerView:pickerView)
    }
    
    func givePickerCount(forPickerView:UIPickerView)->Int{
        switch forPickerView.tag {
        case 0:
            return IManageProducts.count
        case 1:
            return DeploymentTypes.count
        case 2:
            return TypeOfOrganisations.count
        case 3:
            return TimeFrame.count
        case 4:
            return SDFCAccountType.count
        case 5:
            return urgency.count
        default:
            return 0
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let titleArray = labelsArray[pickerView.tag]
        return titleArray[row]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let titleArray = labelsArray[pickerView.tag]
        print(labelsArray[pickerView.tag][row])
        print(titleArray[row])
        updateFormFieldData(selectedPickerView: pickerView, selectedrow: row)
        
    }
    
    func updateFormFieldData(selectedPickerView pickerView:UIPickerView , selectedrow row:Int){
        identifyLabel(selectedPickerView: pickerView).text = labelsArray[pickerView.tag][row]
        labelsValuesDictionary.updateValue(labelsArray[pickerView.tag][row], forKey:labelNamesArray[pickerView.tag] )
        print("key is \(labelNamesArray[pickerView.tag]) and the value is \(labelsArray[pickerView.tag][row])")
        
    }
    
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 36.0
    }
    
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return 200
    }
    
    func identifyLabel(selectedPickerView pickerView:UIPickerView) -> UILabel{
        switch pickerView.tag {
        case 0:
            return listOfProductsLabel
        case 1:
            return deploymentTypeLabel
        case 2:
            return organisationTypeLabel
        case 3:
            return timeFrameLabel
        case 4:
            return accountTypeLabel
        case 5:
            return urgencyTypeLabel
        default:
            return listOfProductsLabel
        }
        
    }
    
}

