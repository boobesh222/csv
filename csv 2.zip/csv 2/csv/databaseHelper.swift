//
//  File.swift
//  csv
//
//  Created by IPhone Dev on 22/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper{
    
    var managedObjectContext:NSManagedObjectContext?
    
    init (){
        
        guard let modelURL = Bundle.main.url(forResource: "csvCoreData", withExtension:"momd")else{
            print("error in getting model URL")
            return
        }
        
        // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
        
        guard let mom = NSManagedObjectModel(contentsOf: modelURL) else {
            fatalError("Error initializing mom from: \(modelURL)")
            return
        }
        
        let psc = NSPersistentStoreCoordinator(managedObjectModel: mom)
        
        managedObjectContext = NSManagedObjectContext(concurrencyType: NSManagedObjectContextConcurrencyType.mainQueueConcurrencyType)
        managedObjectContext?.persistentStoreCoordinator = psc
        
        let queue = DispatchQueue.global(qos: DispatchQoS.QoSClass.background)
        queue.async {
            guard let docURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last else {
                fatalError("Unable to resolve document directory")
            }
            print("obtained doc url")
            let storeURL = docURL.appendingPathComponent("csvCoreData.sqlite")
            do {
                try psc.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: storeURL, options: nil)
                //The callback block is expected to complete the User Interface and therefore should be presented back on the main queue so that the user interface does not need to be concerned with which queue this call is coming from.
                print("obtained persistent store ")
                
            } catch {
                fatalError("Error migrating store: \(error)")
            }
        }
        
        print("core data initialization sucess ")
        
    }
    
    
    func InsertFormDetails(formFields fields:[String:String]){
        let imanageFormObject = NSEntityDescription.insertNewObject(forEntityName: "IManageFom", into: managedObjectContext!) as! IManageFom
        
       imanageFormObject.firstname = fields["firstname"]
        imanageFormObject.lastname = fields["lastName"]
        imanageFormObject.email = fields["email"]
        imanageFormObject.company = fields["comoany"]
        imanageFormObject.title = fields["notes"]
        //imanageFormObject.phonenumber = Int16(fields["phoneNumber"]!)!
        imanageFormObject.notes = fields["notes"]
        imanageFormObject.products = fields["selectedProducts"]
        imanageFormObject.organisationtype = fields["selectedOrganisation_Types"]
        imanageFormObject.timeframe = fields["selectedtimeFrame"]
        imanageFormObject.deploymenttype = fields["selectedDeployment_Types"]
        imanageFormObject.account = fields["selectedAccountType"]
        imanageFormObject.urgency = Int16(fields["selectedUrgencyType"]!)!
        
                do{
                    try managedObjectContext?.save()
                    print("data saved successfully ")
                }catch{
                   print("fatal error in updating the table")
                }
        
    }
    
    
    func fetchFormDetails(){
        let fetchrequest:NSFetchRequest<IManageFom> = IManageFom.fetchRequest()
        do{
            let result = try managedObjectContext!.fetch(fetchrequest)
            print("the search results are result \(result.count)")
            
            for details in result as [IManageFom]{
                print(details.firstname)
                print(details.lastname)
                print(details.email)
                print(details.company)
                print(details.title)
                print(details.phonenumber)
                print(details.notes)
                print(details.products)
                print(details)
            }
            
            
        }catch let error as NSError{
            print("the error is \(error)")
        }
        
    }
    
}
