//
//  File.swift
//  csv
//
//  Created by IPhone Dev on 22/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper{
    
    func getManageObjectContext(){
        
      
        let entityDescription = NSEntityDescription.entity(forEntityName:  "FormTable", in: getManagedObjectContext())
        let formtable = NSManagedObject(entity: entityDescription!, insertInto: getManagedObjectContext())
        formtable.setValue("boobesh", forKey:"name")
        formtable.setValue(1962 , forKey: "age")
        
        do{
            try getManagedObjectContext().save()
            print("the datas are saved ")
        }catch let error as NSError{
            print("the error is \(error)")
        }
    }
    
    
    func getManagedObjectContext()->NSManagedObjectContext{
        
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = delegate.persistentContainer.viewContext
        //return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }

}
