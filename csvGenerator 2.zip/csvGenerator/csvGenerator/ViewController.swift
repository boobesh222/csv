//
//  ViewController.swift
//  csvGenerator
//
//  Created by Boobesh Balasubramanian on 12/03/17.
//  Copyright © 2017 Boobesh Balasubramanian. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    
    @IBOutlet weak var Age: UITextField!
    
    @IBOutlet weak var Name: UITextField!
    
    
    
    @IBAction func sumitButton(_ sender: UIButton) {
        let entityDescription = NSEntityDescription.entity(forEntityName:  "FormTable", in: getManagedObjectContext())
        let formtable = NSManagedObject(entity: entityDescription!, insertInto: getManagedObjectContext())
        formtable.setValue("boobesh", forKey:"name")
        formtable.setValue(1962 , forKey: "age")
        
        do{
            try getManagedObjectContext().save()
              print("the datas are saved ")
        }catch let error as NSError{
            print("the error is \(error)")
        }
        
    }
    
    func fetchDatabaseDetails(){
        let fetchrequest:NSFetchRequest<FormTable> = FormTable.fetchRequest()
        do{
           let result = try getManagedObjectContext().fetch(fetchrequest)
           print("the search results are result \(result.count)")
            
            for details in result as [NSManagedObject]{
                print(details.value(forKey: "name"))
                print(details.value(forKey: "age"))
            }
            
            
        }catch let error as NSError{
          print("the error is \(error)")
        }
        
    }
    
   
    @IBAction func csvGeneratorButton(_ sender: UIButton) {
        //fetchDatabaseDetails()
    }
    
    
    
    func getManagedObjectContext()->NSManagedObjectContext{
        return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

